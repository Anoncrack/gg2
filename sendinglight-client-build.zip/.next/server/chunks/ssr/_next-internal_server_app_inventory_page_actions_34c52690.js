module.exports=[94186,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_inventory_page_actions_34c52690.js.map