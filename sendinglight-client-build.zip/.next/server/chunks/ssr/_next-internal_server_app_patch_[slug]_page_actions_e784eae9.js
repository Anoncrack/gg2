module.exports=[59579,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_patch_%5Bslug%5D_page_actions_e784eae9.js.map