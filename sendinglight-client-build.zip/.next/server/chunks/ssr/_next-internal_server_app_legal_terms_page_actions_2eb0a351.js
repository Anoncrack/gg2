module.exports=[32457,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_legal_terms_page_actions_2eb0a351.js.map