module.exports=[89827,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_legal_privacy_page_actions_58e1a65f.js.map