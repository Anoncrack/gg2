module.exports=[74294,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_lucky-event_page_actions_e1376d67.js.map